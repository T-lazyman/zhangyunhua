# works with data.frames sample arg

    Code
      sparsity(mtcars, sample = 0.4)
    Condition
      Error in `sparsity()`:
      ! `sample` must be a whole number or `NULL`, not the number 0.4.

