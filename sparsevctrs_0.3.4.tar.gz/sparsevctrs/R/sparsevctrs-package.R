#' @keywords internal
"_PACKAGE"

#' @import rlang
#' @keywords internal
NULL

## usethis namespace: start
#' @useDynLib sparsevctrs, .registration = TRUE
## usethis namespace: end
NULL
