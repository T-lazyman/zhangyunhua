if (file.exists(f <- '../examples/_run.R')) sys.source(f, globalenv(), chdir = TRUE)
