### R code from vignette source 'Inserting_figures_and_evaluated_examples.Rnw'

###################################################
### code chunk number 1: Inserting_figures_and_evaluated_examples.Rnw:19-21
###################################################
library(Rdpack)
pd <- packageDescription("Rdpack")


